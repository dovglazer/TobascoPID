"""TobascoPID.com: free custom alignment-collar files for any round x-ray cone."""
from __future__ import annotations

import asyncio
import base64
import json
import multiprocessing
import os
import re
import secrets
import sqlite3
import time
from collections import defaultdict, deque
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path

import httpx
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .cones import library
from .generator import DESIGN_REV, ConeInput, InputError, build_package

BASE = Path(__file__).parent
DATA = Path(os.environ.get("TOBASCO_DATA", BASE.parent / "data"))
(DATA / "photos").mkdir(parents=True, exist_ok=True)
(DATA / "files").mkdir(parents=True, exist_ok=True)
DB = DATA / "requests.sqlite3"
RESEND_API_KEY = os.environ.get("RESEND_API_KEY")          # optional: email the file
MAIL_FROM = os.environ.get("MAIL_FROM", "TobascoPID <files@tobascopid.com>")
SITE_URL = os.environ.get("SITE_URL", "https://tobascopid.com")
MAX_PHOTO = 12 * 1024 * 1024
RATE = int(os.environ.get("RATE_PER_HOUR", "20"))
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN")                # enables /admin/requests.csv

app = FastAPI(title="TobascoPID", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
templates = Jinja2Templates(directory=BASE / "templates")
# "spawn": CAD workers must not inherit the web server's listening socket
_pool = ProcessPoolExecutor(max_workers=int(os.environ.get("CAD_WORKERS", "2")),
                            mp_context=multiprocessing.get_context("spawn"))
_hits: dict[str, deque] = defaultdict(deque)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _db():
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS requests(
        id INTEGER PRIMARY KEY, created REAL, email TEXT, practice TEXT, cone_id TEXT,
        tip_od REAL, base_od REAL, cone_length REAL, photo TEXT, token TEXT,
        spec TEXT, emailed INTEGER, ip TEXT)""")
    return con


def _rate_ok(ip: str) -> bool:
    q, now = _hits[ip], time.time()
    while q and now - q[0] > 3600:
        q.popleft()
    if len(q) >= RATE:
        return False
    q.append(now)
    return True


def _page(request: Request, name: str, **ctx):
    return templates.TemplateResponse(request, name, {"design_rev": DESIGN_REV, **ctx})


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return _page(request, "index.html", cones_json=json.dumps(library()))


@app.get("/terms", response_class=HTMLResponse)
def terms(request: Request):
    return _page(request, "terms.html")


@app.get("/privacy", response_class=HTMLResponse)
def privacy(request: Request):
    return _page(request, "privacy.html")


@app.get("/api/cones")
def cones():
    return library()


@app.get("/healthz")
def healthz():
    return {"ok": True}


def _to_mm(v: str, units: str) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        raise InputError("measurements must be numbers")
    return x * 25.4 if units == "in" else x


async def _send_email(to: str, zip_bytes: bytes, spec: dict, link: str) -> bool:
    if not RESEND_API_KEY:
        return False
    body = (f"<p>Your TobascoPID collar file is attached (STEP + STL + print instructions).</p>"
            f"<p>Collar OD {spec['collar_od']} mm. Print 2 identical halves in MJF Nylon PA 12, "
            f"and line each with a {spec['liner_strip_w']} × {spec['liner_strip_l']} mm strip of "
            f"1/16 in adhesive silicone sheet.</p><p>Download again: <a href='{link}'>{link}</a></p>"
            f"<p style='color:#666;font-size:12px'>Provided free and as is. Printing, fitting and "
            f"clinical use are the user's responsibility. Terms: {SITE_URL}/terms</p>")
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post("https://api.resend.com/emails",
                         headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
                         json={"from": MAIL_FROM, "to": [to],
                               "subject": "Your TobascoPID collar file",
                               "html": body,
                               "attachments": [{"filename": "TobascoPID_collar.zip",
                                                "content": base64.b64encode(zip_bytes).decode()}]})
    return r.status_code < 300


@app.post("/api/generate")
async def generate(request: Request,
                   email: str = Form(...), practice: str = Form(""),
                   cone_id: str = Form(""), units: str = Form("mm"),
                   tip_od: str = Form(...), base_od: str = Form(...), cone_length: str = Form(...),
                   agree: str = Form(""), website: str = Form(""),   # website = honeypot
                   photo: UploadFile = File(...)):
    ip = request.client.host if request.client else "?"
    if website:
        raise HTTPException(400, "rejected")
    if not _rate_ok(ip):
        raise HTTPException(429, "Too many requests from this network. Try again in an hour.")
    email = email.strip()
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "Please enter a valid email address.")
    if agree != "yes":
        raise HTTPException(400, "Please accept the terms and disclaimer.")
    if units not in ("mm", "in"):
        raise HTTPException(400, "Units must be mm or in.")
    lib = {c["id"]: c for c in library()}
    cone = lib.get(cone_id)
    if cone and not cone["supported"]:
        raise HTTPException(400, "Rectangular and handheld cones are not supported yet.")

    raw = await photo.read(MAX_PHOTO + 1)
    if len(raw) > MAX_PHOTO:
        raise HTTPException(400, "Photo is larger than 12 MB.")
    if not (photo.content_type or "").startswith("image/"):
        raise HTTPException(400, "Please upload a photo (JPG, PNG or HEIC).")

    try:
        c = ConeInput(_to_mm(tip_od, units), _to_mm(base_od, units), _to_mm(cone_length, units))
        c.validate()
    except InputError as e:
        raise HTTPException(400, str(e)[0].upper() + str(e)[1:] + ".")

    label = f"{cone['brand']} {cone['model']}, {cone['option']}" if cone else "Other / not listed"
    loop = asyncio.get_running_loop()
    try:
        zip_bytes, spec = await loop.run_in_executor(_pool, build_package, c, label)
    except InputError as e:
        raise HTTPException(400, str(e))
    except Exception:
        raise HTTPException(500, "We could not build a collar for these measurements. "
                                 "Please check them, or contact us.")

    token = secrets.token_urlsafe(16)
    ext = Path(photo.filename or "photo.jpg").suffix.lower()[:6] or ".jpg"
    photo_name = f"{token}{ext}"
    (DATA / "photos" / photo_name).write_bytes(raw)
    (DATA / "files" / f"{token}.zip").write_bytes(zip_bytes)
    spec_d = asdict(spec)
    link = f"{SITE_URL}/download/{token}"
    emailed = False
    try:
        emailed = await _send_email(email, zip_bytes, spec_d, link)
    except Exception:
        emailed = False
    with _db() as con:
        con.execute("INSERT INTO requests(created,email,practice,cone_id,tip_od,base_od,cone_length,"
                    "photo,token,spec,emailed,ip) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    (time.time(), email, practice.strip()[:200], cone_id[:200], c.tip_od, c.base_od,
                     c.cone_length, photo_name, token, json.dumps(spec_d), int(emailed), ip))
    return JSONResponse({"download": f"/download/{token}", "emailed": emailed,
                         "spec": spec_d, "design_rev": DESIGN_REV, "cone": label})


@app.get("/download/{token}")
def download(token: str):
    if not re.fullmatch(r"[A-Za-z0-9_\-]{10,40}", token):
        raise HTTPException(404)
    p = DATA / "files" / f"{token}.zip"
    if not p.exists():
        raise HTTPException(404, "File not found or expired.")
    return FileResponse(p, media_type="application/zip", filename="TobascoPID_collar.zip")


@app.get("/admin/requests.csv")
def admin_requests(token: str = ""):
    """All requests as CSV. Set ADMIN_TOKEN; open /admin/requests.csv?token=..."""
    if not ADMIN_TOKEN or not secrets.compare_digest(token, ADMIN_TOKEN):
        raise HTTPException(404)
    import csv, io as _io
    out = _io.StringIO()
    w = csv.writer(out)
    w.writerow(["created_utc", "email", "practice", "cone", "tip_od_mm", "base_od_mm",
                "cone_length_mm", "photo_url", "download_url", "emailed"])
    with _db() as con:
        for r in con.execute("SELECT created,email,practice,cone_id,tip_od,base_od,cone_length,"
                             "photo,token,emailed FROM requests ORDER BY id DESC"):
            w.writerow([time.strftime("%Y-%m-%d %H:%M", time.gmtime(r[0])), r[1], r[2], r[3],
                        r[4], r[5], r[6], f"{SITE_URL}/admin/photo/{r[7]}?token={token}",
                        f"{SITE_URL}/download/{r[8]}", r[9]])
    return PlainTextResponse(out.getvalue(), media_type="text/csv")


@app.get("/admin/photo/{name}")
def admin_photo(name: str, token: str = ""):
    if not ADMIN_TOKEN or not secrets.compare_digest(token, ADMIN_TOKEN):
        raise HTTPException(404)
    p = DATA / "photos" / Path(name).name
    if not p.exists():
        raise HTTPException(404)
    return FileResponse(p)
