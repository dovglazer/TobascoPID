(function () {
  const cones = window.CONES || [];
  const sel = document.getElementById("cone");
  const hint = document.getElementById("cone-hint");
  const form = document.getElementById("req");
  const err = document.getElementById("err");
  const busy = document.getElementById("busy");
  const go = document.getElementById("go");
  const done = document.getElementById("done");
  const MM = 25.4;
  let units = "mm";

  // ---- cone list, grouped by brand
  const first = new Option("Choose your x-ray unit and cone…", "");
  first.disabled = true; first.selected = true; sel.add(first);
  const byBrand = {};
  cones.forEach(c => (byBrand[c.brand] = byBrand[c.brand] || []).push(c));
  Object.keys(byBrand).sort().forEach(b => {
    const g = document.createElement("optgroup"); g.label = b;
    byBrand[b].forEach(c => {
      const o = new Option(`${c.model} · ${c.option}` + (c.supported ? "" : " (not supported yet)"), c.id);
      o.disabled = !c.supported; g.appendChild(o);
    });
    sel.appendChild(g);
  });
  const other = document.createElement("optgroup"); other.label = "Other";
  other.appendChild(new Option("My cone is not listed (round cone)", "other"));
  sel.appendChild(other);

  const field = n => form.elements[n];
  const fmt = v => (units === "in" ? (v / MM).toFixed(3) : (+v).toFixed(1));

  sel.addEventListener("change", () => {
    const c = cones.find(x => x.id === sel.value);
    if (!c) { hint.textContent = "Enter your own measurements below."; return; }
    const ssd = c.ssd ? `${c.ssd} mm source-to-skin distance. ` : "";
    if (c.tip_od) {
      field("tip_od").value = fmt(c.tip_od); field("base_od").value = fmt(c.base_od);
      field("cone_length").value = fmt(c.length);
      hint.textContent = ssd + "Dimensions filled in from our library. Check them against your cone.";
    } else {
      hint.textContent = ssd + "We don't have measured dimensions for this cone yet. Please measure it.";
    }
  });

  // ---- units toggle converts what is already typed
  form.querySelectorAll("input[name=units]").forEach(r => r.addEventListener("change", () => {
    const next = form.querySelector("input[name=units]:checked").value;
    if (next === units) return;
    ["tip_od", "base_od", "cone_length"].forEach(n => {
      const v = parseFloat(field(n).value);
      if (!isNaN(v)) field(n).value = next === "in" ? (v / MM).toFixed(3) : (v * MM).toFixed(1);
    });
    units = next;
    form.querySelectorAll(".u").forEach(s => (s.textContent = units === "in" ? "in" : "mm"));
  }));

  // ---- photo preview
  field("photo").addEventListener("change", e => {
    const f = e.target.files[0], img = document.getElementById("preview");
    if (!f) { img.hidden = true; return; }
    img.src = URL.createObjectURL(f); img.hidden = false;
  });

  form.addEventListener("input", () => { err.hidden = true; });
  form.addEventListener("change", () => { err.hidden = true; });

  function fail(msg) { err.textContent = msg; err.hidden = false; err.scrollIntoView({ block: "center", behavior: "smooth" }); }

  form.addEventListener("submit", async e => {
    e.preventDefault(); err.hidden = true;
    if (!sel.value) return fail("Please choose your x-ray unit and cone, or “My cone is not listed”.");
    for (const n of ["tip_od", "base_od", "cone_length"]) {
      if (isNaN(parseFloat(field(n).value))) return fail("Please enter all three measurements as numbers.");
    }
    if (!field("photo").files.length) return fail("Please add a photo of the cone with a ruler beside it.");
    if (!field("email").value.includes("@")) return fail("Please enter your email address.");
    if (!field("agree").checked) return fail("Please accept the terms and disclaimer.");

    const fd = new FormData(form);
    if (sel.value === "other") fd.set("cone_id", "");
    go.disabled = true; busy.hidden = false;
    try {
      const r = await fetch("/api/generate", { method: "POST", body: fd });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.detail || "Something went wrong. Please try again.");
      showDone(j);
    } catch (x) { fail(x.message); }
    finally { go.disabled = false; busy.hidden = true; }
  });

  function showDone(j) {
    const s = j.spec;
    document.getElementById("done-cone").textContent = j.cone + " · design revision " + j.design_rev;
    document.getElementById("dl").href = j.download;
    document.getElementById("mailnote").textContent = j.emailed
      ? "We also emailed the file to you."
      : "Download it now. Email delivery is not switched on in this prototype.";
    const rows = [
      ["Print", "2 identical halves"],
      ["Collar outside diameter", s.collar_od + " mm"],
      ["Collar length", s.collar_len + " mm"],
      ["Bore (front / back)", s.bore_front + " / " + s.bore_back + " mm"],
      ["Liner strips (cut 2)", s.liner_strip_w + " × " + s.liner_strip_l + " mm, 1/16 in silicone"],
    ];
    document.getElementById("spec").innerHTML = rows.map(([a, b]) => `<dt>${a}</dt><dd>${b}</dd>`).join("");
    form.hidden = true; done.hidden = false;
    done.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  document.getElementById("again").addEventListener("click", e => {
    e.preventDefault(); done.hidden = true; form.hidden = false; form.reset(); units = "mm";
    form.querySelectorAll(".u").forEach(s => (s.textContent = "mm"));
    document.getElementById("preview").hidden = true; hint.textContent = "";
  });
})();
