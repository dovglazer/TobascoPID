(function () {
  const cones = window.CONES || [];
  const sel = document.getElementById("cone");
  const hint = document.getElementById("cone-hint");
  const form = document.getElementById("req");
  const err = document.getElementById("err");
  const busy = document.getElementById("busy");
  const go = document.getElementById("go");
  const done = document.getElementById("done");
  const MM = 25.4;
  let units = "mm";

  // ---- cone list, grouped by brand
  const block = document.getElementById("measure-block");
  const first = new Option("Choose your brand, model and cone…", "");
  first.disabled = true; first.selected = true; sel.add(first);
  const byBrand = {};
  cones.forEach(c => (byBrand[c.brand] = byBrand[c.brand] || []).push(c));
  Object.keys(byBrand).sort().forEach(b => {
    const g = document.createElement("optgroup"); g.label = b;
    byBrand[b].forEach(c => {
      const tag = !c.supported ? " (not supported yet)" : (c.tip_od ? "" : " (enter measurements)");
      const o = new Option(`${c.brand} ${c.model} · ${c.option}${tag}`, c.id);
      o.disabled = !c.supported; g.appendChild(o);
    });
    sel.appendChild(g);
  });
  const other = document.createElement("optgroup"); other.label = "Other";
  other.appendChild(new Option("My cone is not listed: I'll enter 3 measurements", "other"));
  sel.appendChild(other);

  const field = n => form.elements[n];
  const fmt = v => (units === "in" ? (v / MM).toFixed(3) : (+v).toFixed(1));

  const ready = () => { const c = cones.find(x => x.id === sel.value); return !!(c && c.tip_od); };
  sel.addEventListener("change", () => {
    const c = cones.find(x => x.id === sel.value);
    if (c && c.tip_od) {
      block.hidden = true;
      hint.textContent = "We have this cone's measurements. Enter your email below and download.";
    } else if (c) {
      block.hidden = false;
      hint.textContent = "We haven't measured this cone yet. Please enter three measurements below; it takes about two minutes.";
    } else {
      block.hidden = false;
      hint.textContent = "";
    }
  });

  // ---- units toggle converts what is already typed
  form.querySelectorAll("input[name=units]").forEach(r => r.addEventListener("change", () => {
    const next = form.querySelector("input[name=units]:checked").value;
    if (next === units) return;
    ["tip_od", "base_od", "cone_length"].forEach(n => {
      const v = parseFloat(field(n).value);
      if (!isNaN(v)) field(n).value = next === "in" ? (v / MM).toFixed(3) : (v * MM).toFixed(1);
    });
    units = next;
    form.querySelectorAll(".u").forEach(s => (s.textContent = units === "in" ? "in" : "mm"));
  }));

  // ---- photo preview
  field("photo").addEventListener("change", e => {
    const f = e.target.files[0], img = document.getElementById("preview");
    if (!f) { img.hidden = true; return; }
    img.src = URL.createObjectURL(f); img.hidden = false;
  });

  form.addEventListener("input", () => { err.hidden = true; });
  form.addEventListener("change", () => { err.hidden = true; });

  function fail(msg) { err.textContent = msg; err.hidden = false; err.scrollIntoView({ block: "center", behavior: "smooth" }); }

  form.addEventListener("submit", async e => {
    e.preventDefault(); err.hidden = true;
    if (!sel.value) return fail("Please choose your x-ray unit, or “My cone is not listed”.");
    if (!ready()) for (const n of ["tip_od", "base_od", "cone_length"]) {
      if (isNaN(parseFloat(field(n).value))) return fail("Please enter all three measurements as numbers.");
    }
    if (!field("email").value.includes("@")) return fail("Please enter your email address.");
    if (!field("agree").checked) return fail("Please accept the terms and disclaimer.");

    const fd = new FormData(form);
    if (sel.value === "other") fd.set("cone_id", "");
    if (ready()) ["tip_od", "base_od", "cone_length", "photo"].forEach(n => fd.delete(n));
    else if (!field("photo").files.length) fd.delete("photo");
    go.disabled = true; busy.hidden = false;
    try {
      const r = await fetch("/api/generate", { method: "POST", body: fd });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.detail || "Something went wrong. Please try again.");
      showDone(j);
    } catch (x) { fail(x.message); }
    finally { go.disabled = false; busy.hidden = true; }
  });

  function showDone(j) {
    const s = j.spec;
    document.getElementById("done-cone").textContent = j.cone + " · design revision " + j.design_rev;
    document.getElementById("dl").href = j.download;
    document.getElementById("mailnote").textContent = j.emailed
      ? "We also emailed the file to you."
      : "Download it now. Email delivery is not switched on in this prototype.";
    const rows = [
      ["Print", "2 identical halves"],
      ["Collar outside diameter", s.collar_od + " mm"],
      ["Collar length", s.collar_len + " mm"],
      ["Bore (front / back)", s.bore_front + " / " + s.bore_back + " mm"],
      ["Liner strips (cut 2)", s.liner_strip_w + " × " + s.liner_strip_l + " mm, 1/16 in silicone"],
    ];
    document.getElementById("spec").innerHTML = rows.map(([a, b]) => `<dt>${a}</dt><dd>${b}</dd>`).join("");
    form.hidden = true; done.hidden = false;
    done.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  document.getElementById("again").addEventListener("click", e => {
    e.preventDefault(); done.hidden = true; form.hidden = false; form.reset(); units = "mm";
    form.querySelectorAll(".u").forEach(s => (s.textContent = "mm"));
    document.getElementById("preview").hidden = true; hint.textContent = ""; block.hidden = true;
  });
})();
