"""
Tobasco "Dumb" alignment collar for Planmeca ProX PID  (Step 1, no electronics)
Parametric CadQuery model.  Units: mm.

Coordinate system
  Z axis  = X-ray beam axis, +Z toward the patient.
  Collar front face (patient end) at Z = 0, flush with the PID tip.
  Looking at the PID tip from the patient side:  +Y = 12 o'clock (top),
  +X = 3 o'clock (right), -Y = 6 o'clock (bottom), -X = 9 o'clock (left).
"""
import math
import cadquery as cq

# ----------------------------------------------------------------- parameters
L          = 35.0    # collar length along the beam (Rev B: half of Rev A)
RO         = 45.5    # collar outer radius  (OD 91)
R_LIP      = 36.5    # bore radius at the two end lips (ID 73)
R_REC      = 37.3    # bore radius of the liner recess
LIP        = 3.0     # axial length of each end lip
CH_OUT     = 1.0     # outer edge chamfer
CH_IN      = 0.5     # bore edge chamfer

# Seams: two identical halves joined by a screwless snap tongue & groove.
SEAM_ANG   = 45.0    # seams at 45 deg and 225 deg -> wand grooves never sit on a seam

# Snap latch (one per seam).  A flexible tongue, cantilevered along the beam
# axis, sticks out of the seam face into a pocket in the other half.  A barb
# on the tongue clicks up into a window in the other half's outer wall: the
# barb top sits flush with the OD and is the release button.
ARM_R0, ARM_R1 = 42.0, 43.6   # tongue radial span (thickness 1.6)
ARM_IN     = 3.0     # tongue width inside its own half (from seam face)
ARM_OUT    = 8.0     # how far the tongue sticks out of the seam face
ARM_ZR     = -31.0   # root of the cantilever (rear)
ARM_ZF     = -6.0    # free end (front)  -> 25 mm flexing length
BARB_Z     = (-11.0, -6.0)   # axial span of the barb / button (at the tongue tip)
BARB_Y0    = 2.5     # retention face, measured from the seam face
BARB_TOPEND = 5.0    # end of the flat button top; ramp runs from here to tongue tip
GAP_FLOOR  = 39.2    # deflection space under the tongue (2.8 mm)
SLIT       = 0.6     # slits freeing the tongue inside its own half (MJF min gap 0.5)
SLIT_SIDE  = 0.8
POCKET_CEIL = 43.8   # pocket ceiling in the mating half (0.2 above tongue)
POCKET_CLR = 0.3     # pocket clearance at the tongue tip and both sides
WIN_CLR    = 0.2     # window clearance around the barb

# Wand grooves (user spec): 3.1 wide, accepts the wand's 3.0 rail
GROOVE_ANGS = (90.0, 0.0, 270.0, 180.0)   # top, right, bottom, left
GROOVE_W   = 3.1
GROOVE_D   = 3.0
GROOVE_STOP = 6.0    # closed rear end (depth stop), mm from the rear face
LEADIN_W, LEADIN_L = 4.1, 2.0   # flared entry at the patient end

# Magnets: N52 disc 6 x 2.  Collar magnets load from the bore side, 0.8 mm
# skin under the groove floor; the silicone liner covers them.
MAG_D, MAG_T = 6.0, 2.0
MAG_SKIN   = 1.0
MAG_Z      = ()       # Rev C: no magnets (KISS trial version)

# Silicone liners (one pair per PID size); 0.4 mm radial squeeze
LINER_SQUEEZE = 0.4
LINER_CLR_Z   = 0.2
PID_SIZES  = (60.0, 65.0, 70.0)

# Wand
RAIL_W, RAIL_H = 3.0, 2.8          # rail drops into the 3.1 x 3.0 groove
BODY_W, BODY_T = 8.0, 3.0          # shaft body rides on the collar OD
SHAFT_REAR = -(L - GROOVE_STOP) + 0.2
Z_SENSOR   = 45.0  # PID tip -> sensor front face (clinical parameter)
DROP       = RO + BODY_T / 2       # matched drop: shaft centerline -> beam axis

# Sensors (Planmeca ProSensor outline, thickness assumed)
BW_SENSOR  = (44.1, 30.4)  # size 2, landscape
PA_SENSOR  = (39.7, 25.1)  # size 1, portrait
SENSOR_T   = 5.5
SENSOR_CLR = 0.3
WALL       = 1.5
FRONT_WALL = 1.0
WAND_MAG_FLOOR = 0.8


# ----------------------------------------------------------------- helpers
def box(x0, x1, y0, y1, z0, z1):
    return cq.Workplane("XY").add(
        cq.Solid.makeBox(x1 - x0, y1 - y0, z1 - z0, cq.Vector(x0, y0, z0)))


def cyl(r, h, p, d):
    return cq.Workplane("XY").add(
        cq.Solid.makeCylinder(r, h, cq.Vector(*p), cq.Vector(*d)))


def rotz(wp, ang):
    return wp.rotate((0, 0, 0), (0, 0, 1), ang)


# ----------------------------------------------------------------- latch
def latch_tongue():
    """Flexible tongue + barb in the half's LOCAL frame (+X seam)."""
    t_in = box(ARM_R0, ARM_R1, 0.0, ARM_IN, ARM_ZR - 0.5, ARM_ZF)       # inside own half
    t_out = box(ARM_R0, ARM_R1, -ARM_OUT, 0.01, ARM_ZR, ARM_ZF)          # sticks out
    # barb profile in (x = radius, y = tangential); retention face square,
    # 31 deg lead-in ramp toward the tongue tip
    slope = (RO - 0.1 - ARM_R1) / (ARM_OUT - BARB_TOPEND)
    y_top = -BARB_TOPEND + (RO + 1 - (RO - 0.1)) / slope
    pts = [(ARM_R1 - 0.1, -BARB_Y0), (RO + 1, -BARB_Y0), (RO + 1, y_top),
           (ARM_R1, -ARM_OUT), (ARM_R1 - 0.1, -ARM_OUT)]
    barb = (cq.Workplane("XY", origin=(0, 0, BARB_Z[0])).polyline(pts).close()
            .extrude(BARB_Z[1] - BARB_Z[0]))
    barb = barb.intersect(cyl(RO - 0.1, 200, (0, 0, -100), (0, 0, 1)))  # flush button
    return t_in.union(t_out).union(barb)


# ----------------------------------------------------------------- collar half
def collar_half():
    """Half shell in its LOCAL frame: seams on the X axis, body in +Y.
    Snap tongue on the +X seam, pocket + window on the -X seam
    -> two identical parts (the second is rotated 180 deg)."""
    pts = [
        (R_LIP + CH_IN, -L), (RO - CH_OUT, -L), (RO, -L + CH_OUT),
        (RO, -CH_OUT), (RO - CH_OUT, 0.0), (R_LIP + CH_IN, 0.0),
        (R_LIP, -CH_IN), (R_LIP, -LIP), (R_REC, -LIP),
        (R_REC, -L + LIP), (R_LIP, -L + LIP), (R_LIP, -L + CH_IN),
    ]
    ring = (cq.Workplane("XZ").polyline(pts).close()
            .revolve(360, (0, 0, 0), (0, 1, 0)))
    half = ring.intersect(box(-60, 60, 0, 60, -L - 1, 1))

    # --- own latch tongue on the +X seam (sticks out into -Y)
    half = half.cut(box(GAP_FLOOR, ARM_R1 + SLIT, -0.01, ARM_IN + SLIT_SIDE,
                        ARM_ZR, ARM_ZF + SLIT_SIDE))          # free the tongue
    half = half.union(latch_tongue())
    # --- pocket + window on the -X seam for the mating half's tongue
    half = half.cut(box(-POCKET_CEIL, -GAP_FLOOR, -0.01, ARM_OUT + POCKET_CLR,
                        ARM_ZR - POCKET_CLR, ARM_ZF + POCKET_CLR))
    half = half.cut(box(-(RO + 2), -POCKET_CEIL + 0.01, BARB_Y0 - WIN_CLR,
                        ARM_OUT + POCKET_CLR, BARB_Z[0] - WIN_CLR, BARB_Z[1] + WIN_CLR))

    # wand grooves that fall in this half (local angles 45 and 135)
    for a in (45.0, 135.0):
        g = box(RO - GROOVE_D, RO + 2, -GROOVE_W / 2, GROOVE_W / 2,
                -(L - GROOVE_STOP), 1)
        g = g.union(box(RO - GROOVE_D, RO + 2, -LEADIN_W / 2, LEADIN_W / 2,
                        -LEADIN_L, 1))
        for z in MAG_Z:
            r_top = RO - GROOVE_D - MAG_SKIN
            g = g.union(cyl(MAG_D / 2 + 0.05, r_top - (R_REC - 1),
                            (R_REC - 1, 0, z), (1, 0, 0)))
        half = half.cut(rotz(g, a))
    return half


def liner_half(pid_od):
    r_in = pid_od / 2 - LINER_SQUEEZE
    zl0, zl1 = -L + LIP + LINER_CLR_Z, -LIP - LINER_CLR_Z
    sh = (cq.Workplane("XY").workplane(offset=zl0)
          .circle(R_REC).circle(r_in).extrude(zl1 - zl0))
    return sh.intersect(box(-60, 60, 0, 60, zl0 - 1, zl1 + 1))


# ----------------------------------------------------------------- wands
def shaft(z_end):
    """Shaft in its local frame (groove at +X).  Concave underside matches
    the collar OD; 3.0 rail on the underside."""
    body = box(RO - 0.5, RO + BODY_T, -BODY_W / 2, BODY_W / 2, SHAFT_REAR, z_end)
    body = body.cut(cyl(RO, 400, (0, 0, -200), (0, 0, 1)))
    rail = box(RO - RAIL_H, RO + 0.2, -RAIL_W / 2, RAIL_W / 2,
               SHAFT_REAR, -0.5)   # rail stops just short of the PID tip
    s = body.union(rail)
    for z in MAG_Z:   # wand magnets, loaded from the top face, 0.6 floor
        s = s.cut(cyl(MAG_D / 2 + 0.05, BODY_T, (RO + WAND_MAG_FLOOR, 0, z), (1, 0, 0)))
    return s


def holder(w_u, h_t, open_end_plus_u=True):
    """Sensor sleeve centred on the beam axis.  w_u along the wand's radial
    direction, h_t along its tangential direction.  Front wall 0.8 thick
    (radiolucent); open at one end for loading / cable exit."""
    pu, pt = w_u / 2 + SENSOR_CLR, h_t / 2 + SENSOR_CLR
    zf = Z_SENSOR - FRONT_WALL
    zb = Z_SENSOR + SENSOR_T + 0.4
    outer = box(-pu - WALL, pu + (0 if open_end_plus_u else WALL),
                -pt - WALL, pt + WALL, zf, zb + WALL)
    pocket = box(-pu, pu + (WALL + 1 if open_end_plus_u else 0),
                 -pt, pt, Z_SENSOR, zb)
    return outer.cut(pocket)


def bw_wand():
    """Bitewing wand, local frame.  Rotate so +X points to the chosen groove.
    The drop arm is a flat plate in the plane of the shaft and beam axis:
    on the 3 / 9 o'clock grooves that plane is the occlusal plane, so the
    arm doubles as the bite tab across the sensor centre line."""
    W, H = BW_SENSOR
    zf = Z_SENSOR - FRONT_WALL
    arm = box(-(W / 2 + SENSOR_CLR + WALL), RO + BODY_T, -1.25, 1.25,
              zf - 12.0, zf)
    return shaft(zf).union(arm).union(holder(W, H))


def pa_wand():
    """Periapical wand, local frame.  Sensor portrait (long side along the
    drop).  Riser from the shaft to a bite block near the sensor edge on the
    shaft side; the tooth sits on the block, the sensor extends past it."""
    Lp, Wp = PA_SENSOR
    zf = Z_SENSOR - FRONT_WALL
    u_block = Lp / 2 - 6.0          # bite block 6 mm in from the sensor edge
    blk_len = 20.0
    block = box(u_block, u_block + 3.0, -6.0, 6.0, zf - blk_len, zf)
    riser = box(u_block, RO + BODY_T, -1.5, 1.5, zf - blk_len, zf - blk_len + 6.0)
    return (shaft(zf - blk_len + 6.0).union(riser).union(block)
            .union(holder(Lp, Wp, open_end_plus_u=False)))


# ----------------------------------------------------------------- hardware
def magnet():
    return cyl(MAG_D / 2, MAG_T, (0, 0, 0), (1, 0, 0))   # along +X, at origin


def ref_pid(od=70.0):
    return (cq.Workplane("XY").workplane(offset=-130)
            .circle(od / 2).circle(od / 2 - 3).extrude(130))
