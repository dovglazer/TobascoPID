"""
TobascoPID collar generator.

Takes a cone's measured dimensions and returns a collar half (print 2) sized
to that cone, plus a matching STL and printing instructions.

Geometry = Rev C snap-fit collar (collar_base.py), re-sized around the
cone's measured, possibly tapered, outside diameter.  Swap in the validated
Rev D geometry by editing collar_base.py: this module only re-sizes it.

Fit: the collar is rigid nylon; a strip of adhesive-backed silicone sheet
(default 1/16 in = 1.6 mm) lines the bore and takes up print tolerance.
"""
from __future__ import annotations

import io
import math
import zipfile
from dataclasses import dataclass, asdict

import cadquery as cq

from . import collar_base as cb

DESIGN_REV = "C (prototype)"
COLLAR_LEN = cb.L                       # 35 mm
MIN_OD, MAX_OD = 45.0, 95.0             # sanity limits for a dental cone, mm
LINER_T = 1.6                           # 1/16 in silicone sheet
LINER_SQUEEZE = 0.4                     # radial squeeze of the liner


class InputError(ValueError):
    """Raised for measurements that cannot make a valid collar."""


@dataclass
class ConeInput:
    tip_od: float          # outside diameter at the cone tip (patient end), mm
    base_od: float         # outside diameter at the base (tubehead end), mm
    cone_length: float     # visible length of the cone, mm

    def validate(self) -> None:
        for name in ("tip_od", "base_od", "cone_length"):
            v = getattr(self, name)
            if not isinstance(v, (int, float)) or math.isnan(v):
                raise InputError(f"{name.replace('_', ' ')} must be a number")
        for name, label in (("tip_od", "tip OD"), ("base_od", "base OD")):
            v = getattr(self, name)
            if not MIN_OD <= v <= MAX_OD:
                raise InputError(f"{label} {v:g} mm is outside "
                                 f"{MIN_OD:.0f}-{MAX_OD:.0f} mm; please re-measure")
        if self.cone_length < COLLAR_LEN + 5:
            raise InputError(f"cone length must be at least {COLLAR_LEN + 5:.0f} mm "
                             "(the collar is 35 mm long)")
        if self.cone_length > 400:
            raise InputError("cone length over 400 mm; please re-measure")
        taper = abs(self.base_od - self.tip_od) / self.cone_length
        if taper > 0.25:
            raise InputError("diameters change too fast along the cone; "
                             "check tip and base measurements")


@dataclass
class CollarSpec:
    """Derived numbers, also written into the instructions."""
    cone_od_front: float   # cone OD at collar front (= tip)
    cone_od_back: float    # cone OD 35 mm back from the tip
    bore_front: float      # collar bore at front
    bore_back: float
    collar_od: float
    collar_len: float
    liner_t: float
    liner_strip_w: float
    liner_strip_l: float
    matched_drop: float    # groove-rail centre to beam axis


def spec_for(c: ConeInput) -> CollarSpec:
    taper_per_mm = (c.base_od - c.tip_od) / c.cone_length
    od_front = c.tip_od
    od_back = c.tip_od + taper_per_mm * COLLAR_LEN
    gap = 2 * (LINER_T - LINER_SQUEEZE)
    bore_f, bore_b = od_front + gap, od_back + gap
    r_max = max(bore_f, bore_b) / 2
    delta = r_max - cb.R_REC                     # shift Rev C wall outward/inward
    ro = cb.RO + delta
    mid_r = (bore_f + bore_b) / 4
    return CollarSpec(
        cone_od_front=round(od_front, 2), cone_od_back=round(od_back, 2),
        bore_front=round(bore_f, 2), bore_back=round(bore_b, 2),
        collar_od=round(2 * ro, 2), collar_len=COLLAR_LEN, liner_t=LINER_T,
        liner_strip_w=round(COLLAR_LEN - 1.0, 1),
        liner_strip_l=round(math.pi * mid_r - 1.0, 1),
        matched_drop=round(ro + cb.BODY_T / 2, 2),
    )


def _apply_shift(delta: float) -> dict:
    """Shift every radial parameter of the Rev C wall by delta. Returns the
    originals so they can be restored."""
    names = ["RO", "ARM_R0", "ARM_R1", "GAP_FLOOR", "POCKET_CEIL", "R_LIP", "R_REC"]
    orig = {n: getattr(cb, n) for n in names}
    for n in names:
        setattr(cb, n, orig[n] + delta)
    return orig


def build_half(c: ConeInput) -> cq.Workplane:
    """One collar half in its local frame (front face at Z=0)."""
    c.validate()
    s = spec_for(c)
    rf, rb = s.bore_front / 2, s.bore_back / 2
    delta = max(rf, rb) - cb.R_REC
    orig = _apply_shift(delta)
    try:
        L, RO, CH_IN, CH_OUT = cb.L, cb.RO, cb.CH_IN, cb.CH_OUT
        pts = [(rb + CH_IN, -L), (RO - CH_OUT, -L), (RO, -L + CH_OUT),
               (RO, -CH_OUT), (RO - CH_OUT, 0.0), (rf + CH_IN, 0.0),
               (rf, -CH_IN), (rb, -L + CH_IN)]
        ring = (cq.Workplane("XZ").polyline(pts).close()
                .revolve(360, (0, 0, 0), (0, 1, 0)))
        box, cyl, rotz = cb.box, cb.cyl, cb.rotz
        half = ring.intersect(box(-RO - 5, RO + 5, 0, RO + 5, -L - 1, 1))
        # snap tongue (+X seam) and pocket/window (-X seam), as Rev C
        half = half.cut(box(cb.GAP_FLOOR, cb.ARM_R1 + cb.SLIT, -0.01,
                            cb.ARM_IN + cb.SLIT_SIDE, cb.ARM_ZR, cb.ARM_ZF + cb.SLIT_SIDE))
        half = half.union(cb.latch_tongue())
        half = half.cut(box(-cb.POCKET_CEIL, -cb.GAP_FLOOR, -0.01, cb.ARM_OUT + cb.POCKET_CLR,
                            cb.ARM_ZR - cb.POCKET_CLR, cb.ARM_ZF + cb.POCKET_CLR))
        half = half.cut(box(-(RO + 2), -cb.POCKET_CEIL + 0.01, cb.BARB_Y0 - cb.WIN_CLR,
                            cb.ARM_OUT + cb.POCKET_CLR, cb.BARB_Z[0] - cb.WIN_CLR,
                            cb.BARB_Z[1] + cb.WIN_CLR))
        # four 3.1 x 3.0 rail grooves (two per half) at 12/3/6/9 o'clock
        for a in (45.0, 135.0):
            g = box(RO - cb.GROOVE_D, RO + 2, -cb.GROOVE_W / 2, cb.GROOVE_W / 2,
                    -(L - cb.GROOVE_STOP), 1)
            g = g.union(box(RO - cb.GROOVE_D, RO + 2, -cb.LEADIN_W / 2, cb.LEADIN_W / 2,
                            -cb.LEADIN_L, 1))
            half = half.cut(rotz(g, a))
        # print-friendly orientation is left to the printer / slicer
        return half
    finally:
        for n, v in orig.items():
            setattr(cb, n, v)


def _instructions(c: ConeInput, s: CollarSpec, label: str) -> str:
    return f"""TOBASCO PID ALIGNMENT COLLAR - PRINT PACKAGE
Design revision: {DESIGN_REV}
Cone: {label}

YOUR MEASUREMENTS
  Tip OD ........ {c.tip_od:.2f} mm
  Base OD ....... {c.base_od:.2f} mm
  Cone length ... {c.cone_length:.1f} mm

COLLAR
  Print 2 copies of TobascoPID_collar_half.stl (or .step). Both halves are identical.
  Outside diameter {s.collar_od:.1f} mm, length {s.collar_len:.0f} mm.
  Bore {s.bore_front:.2f} mm at the front, {s.bore_back:.2f} mm at the back
  (cone OD + 2 x liner, liner squeezed {LINER_SQUEEZE} mm).

MATERIAL AND PROCESS
  Recommended: HP Multi Jet Fusion (MJF), Nylon PA 12. The snap tongues are designed for nylon.
  Resin (SLA/DLP) prints may be too brittle for the snap tongue; test before relying on them.
  Clear all powder/resin from the slits around each snap tongue so it can flex.

LINER (makes the collar grip and centre on the cone)
  Adhesive-backed silicone rubber sheet, {s.liner_t} mm (1/16 in), soft (about 40A).
  Cut 2 strips, each {s.liner_strip_w:.1f} mm x {s.liner_strip_l:.1f} mm.
  Stick one strip inside each half; trim flush with the seam faces.

FIT
  1. Place both halves around the cone, collar front flush with the cone tip.
  2. Squeeze together: two clicks, one per seam.
  3. To remove: press both release buttons (one on each seam) and pull apart.
  4. Seat the sensor-holder rail (3.0 mm) in the 12, 3, 6 or 9 o'clock groove (3.1 mm).

DISCLAIMER
  This file is provided free, as is, without warranty. Printing, fitting, inspecting
  and clinically using the collar are the responsibility of the user. Verify alignment
  before clinical use. See https://tobascopid.com/terms
"""


def build_package(c: ConeInput, label: str = "custom") -> tuple[bytes, CollarSpec]:
    """Return a zip (STEP + STL + instructions) and the derived spec."""
    half = build_half(c)
    s = spec_for(c)
    import tempfile, os
    with tempfile.TemporaryDirectory() as td:
        step_p = os.path.join(td, "TobascoPID_collar_half.step")
        stl_p = os.path.join(td, "TobascoPID_collar_half.stl")
        cq.exporters.export(half, step_p)
        cq.exporters.export(half, stl_p, tolerance=0.02, angularTolerance=0.1)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(step_p, "TobascoPID_collar_half.step")
            z.write(stl_p, "TobascoPID_collar_half.stl")
            z.writestr("README_print_instructions.txt", _instructions(c, s, label))
        return buf.getvalue(), s


if __name__ == "__main__":
    import sys
    c = ConeInput(*(float(a) for a in sys.argv[1:4])) if len(sys.argv) > 3 else ConeInput(64.8, 64.8, 200)
    data, s = build_package(c)
    open("/tmp/test_collar.zip", "wb").write(data)
    print(asdict(s), len(data))
