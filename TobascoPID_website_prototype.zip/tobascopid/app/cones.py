"""Cone library shown on the site. Source of truth: the 'TobascoPID Cone Library'
sheet. Tip/base OD and length are filled in as they are measured; until then the
office enters its own measurements. Rectangular cones are listed but not supported."""

# brand, model, cone option, shape, SSD mm, tip OD, base OD, length (None = not measured yet)
_ROWS = [
    ("Planmeca", "ProX", "Short cone (20 cm)", "round", 200),
    ("Planmeca", "ProX", "Long cone (30 cm)", "round", 300),
    ("Planmeca", "ProX", "Long cone + rectangular collimator", "rectangular", 300),
    ("Dentsply Sirona", "Heliodent Plus", "20 cm standard cone", "round", 200),
    ("Dentsply Sirona", "Heliodent Plus", "Round cone extension, 30 cm", "round", 300),
    ("Dentsply Sirona", "Heliodent Plus", "Square cone extension, 30 cm", "rectangular", 300),
    ("Carestream", "CS 2200", "Standard cone", "round", 200),
    ("Carestream", "CS 2200", "Rectangular collimator", "rectangular", 200),
    ("Carestream", "CS 2100", "Standard cone", "round", None),
    ("Gendex", "Expert DC", '8" standard cone', "round", 200),
    ("Gendex", "Expert DC", '12" optional cone', "round", 300),
    ("Gendex", "Expert DC", '8" rectangular cone', "rectangular", 200),
    ("Gendex", "Expert DC", '12" rectangular cone', "rectangular", 300),
    ("KaVo / Instrumentarium", "FOCUS", 'Short cone, round (9")', "round", 229),
    ("KaVo / Instrumentarium", "FOCUS", "Short cone, rectangular", "rectangular", 229),
    ("KaVo / Instrumentarium", "FOCUS", 'Long cone, round (12")', "round", 305),
    ("KaVo / Instrumentarium", "FOCUS", "Long cone, rectangular", "rectangular", 305),
    ("Midmark", "Preva DC / Preva 2.0", '8" cone', "round", 200),
    ("Midmark", "Preva DC / Preva 2.0", '12" cone', "round", 300),
    ("Midmark", "Preva DC / Preva 2.0", "Rectangular cones", "rectangular", None),
    ("Vatech", "EzRay Air W", "Standard cone", "round", 200),
    ("Acteon", "X-Mind Unity", "Short round cone (20 cm)", "round", 200),
    ("Acteon", "X-Mind Unity", "Long round cone (30 cm)", "round", 300),
    ("Acteon", "X-Mind Unity", "Long rectangular cone", "rectangular", 300),
    ("Acteon / Owandy", "X-Mind DC / Owandy-RX DC", "Short round cone (20 cm)", "round", 200),
    ("Acteon / Owandy", "X-Mind DC / Owandy-RX DC", "Long round cone (31 cm)", "round", 310),
    ("Acteon / Owandy", "X-Mind DC / Owandy-RX DC", "Long rectangular cone", "rectangular", 310),
    ("Belmont", "Bel-Ray II (097)", "Regular cone", "round", 204),
    ("Belmont", "Bel-Ray II (097)", "Long cone", "round", 305),
    ("Belmont", "PHOT-X IIs", '8" standard cone', "round", 203),
    ("Belmont", "PHOT-X IIs", '12" long cone', "round", 305),
    ("MyRay", "RXDC", "Short round cone (20 cm)", "round", 200),
    ("MyRay", "RXDC", "Long round cone (30 cm)", "round", 300),
    ("MyRay", "RXDC", "Rectangular cone", "rectangular", 300),
    ("Corix", "70 Plus-USV", "Standard cone", "round", None),
    ("DEXIS / KaVo", "NOMAD Pro 2 (handheld)", "Integral cone with shield", "handheld", 200),
]

# Measured dimensions keyed by (brand, model, option): fill in from GNYDM.
MEASURED: dict[tuple[str, str, str], tuple[float, float, float]] = {}


def library() -> list[dict]:
    out = []
    for brand, model, option, shape, ssd in _ROWS:
        m = MEASURED.get((brand, model, option))
        out.append({
            "id": f"{brand}|{model}|{option}",
            "brand": brand, "model": model, "option": option, "shape": shape, "ssd": ssd,
            "supported": shape == "round",
            "tip_od": m[0] if m else None, "base_od": m[1] if m else None,
            "length": m[2] if m else None,
        })
    return out
